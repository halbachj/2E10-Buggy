#ifndef BUGGY_WIFI_SECRETS_H
#define BUGGY_WIFI_SECRETS_H

#define SECRET_SSID "Trayvon";
#define SECRET_PASS "qwertzuiop";

#endif //BUGGY_WIFI_SECRETS_H
